LoadAddOn("Blizzard_CombatText")

local _, AddOn = ...

local band = bit.band

local COMBATLOG_OBJECT_TARGET = COMBATLOG_OBJECT_TARGET
local COMBATLOG_OBJECT_FOCUS = COMBATLOG_OBJECT_FOCUS

local CombatText_AddMessage = CombatText_AddMessage
local UnitPlayerControlled = UnitPlayerControlled
local UnitIsEnemy = UnitIsEnemy
local UnitIsUnit = UnitIsUnit

local spellDB = {}
local totemDB = {}

local function SpellAlert(spellName)
	CombatText_AddMessage(spellName, nil, 1, 0, 0, "crit")
	PlaySound(8959)
end

local EventHandler = CreateFrame("Frame")

EventHandler:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
EventHandler:RegisterEvent("PLAYER_ENTERING_WORLD")

EventHandler:SetScript("OnEvent", function(self, event, ...)
	if event == "COMBAT_LOG_EVENT_UNFILTERED" then
		local _, eventType, _, _, srcFlags, _, _, dstFlags, spellId, spellName, _, auraType = ...
		
		if UnitPlayerControlled("target") and UnitIsEnemy("player", "target") then
			local srcTarget = band(srcFlags, COMBATLOG_OBJECT_TARGET) > 0
			local dstTarget = band(dstFlags, COMBATLOG_OBJECT_TARGET) > 0
			
			if (srcTarget and eventType == "SPELL_CAST_SUCCESS") or
					(dstTarget and not srcTarget and eventType == "SPELL_AURA_APPLIED" and auraType == "BUFF") then
				for i = 1, #spellDB do
					if spellDB[i] == spellId then
						SpellAlert(spellName)
						break
					end
				end
			elseif srcTarget and eventType == "SPELL_SUMMON" then
				for i = 1, #totemDB do
					if totemDB[i] == spellId then
						SpellAlert(spellName)
						break
					end
				end
			end
		end
		
		if not UnitIsUnit("target", "focus") and UnitPlayerControlled("focus") and UnitIsEnemy("player", "focus") then
			local srcFocus = band(srcFlags, COMBATLOG_OBJECT_FOCUS) > 0
			local dstFocus = band(dstFlags, COMBATLOG_OBJECT_FOCUS) > 0
			
			if (srcFocus and eventType == "SPELL_CAST_SUCCESS") or
					(dstFocus and not srcFocus and eventType == "SPELL_AURA_APPLIED" and auraType == "BUFF") then
				for i = 1, #spellDB do
					if spellDB[i] == spellId then
						SpellAlert("(F) " .. spellName)
						break
					end
				end
			elseif srcFocus and eventType == "SPELL_SUMMON" then
				for i = 1, #totemDB do
					if totemDB[i] == spellId then
						SpellAlert("(F) " .. spellName)
						break
					end
				end
			end
		end
		
	elseif event == "PLAYER_ENTERING_WORLD" then
		local _, instanceType = IsInInstance()
		local _, playerClass = UnitClass("player")
		
		spellDB = {unpack(AddOn.spellDB)}
		
		if tContains({"DRUID", "MAGE", "PALADIN", "PRIEST", "SHAMAN", "WARLOCK"}, playerClass) then
			local interrupts
			
			if UnitLevel("player") > 19 then
				interrupts = {
					57994, -- Wind Shear
					53550, -- Mind Freeze
					1766, -- Kick
					6552, -- Pummel
					72, -- Shield Bash
					2139, -- Counterspell
				}
			else
				interrupts = {
					57994, -- Wind Shear
					1766, -- Kick
					72, -- Shield Bash
				}
			end
			
			for i = 1, #interrupts do
				table.insert(spellDB, 1, interrupts[i])
			end
		end
		
		if UnitLevel("player") > 19 and instanceType ~= "arena" or instanceType == "arena" and not IsAddOnLoaded("TotemSpy") then
			totemDB = {
				8143, -- Tremor Totem
				8170, -- Cleansing Totem
				8177, -- Grounding Totem
				16190, -- Mana Tide Totem
			}
		else
			wipe(totemDB)
		end
	end
end)
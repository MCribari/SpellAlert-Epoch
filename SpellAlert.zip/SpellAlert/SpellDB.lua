local _, AddOn = ...

if UnitLevel("player") > 19 then
	AddOn.spellDB = {
		-- Consume Shadows
		54501,
		-- Track Hidden
		19885,
		-- Aspect of the Cheetah
		5118,
		-- Aspect of the Pack
		13159,
		-- Spell Reflection
		23920,
		-- Intervene
		3411,
		-- Freezing Arrow
		60192,
		-- Freezing Trap
		14311,
		14310,
		1499,
		-- Berserker Rage
		18499,
		-- Anti-Magic Shell
		48707,
		-- Divine Plea
		54428,
		-- Shamanistic Rage
		30823,
		-- Barkskin
		22812,
		-- Cloak of Shadows
		31224,
		-- Deterrence
		19263,
		-- Roar of Sacrifice
		53480,
		-- Master's Call
		54216,
		-- Shield Block
		2565,
		-- Nature's Grasp
		27009,
		17329,
		16813,
		16812,
		16811,
		16810,
		16689,
		-- Sacrifice
		47986,
		47985,
		27273,
		19443,
		19442,
		19441,
		19440,
		19438,
		7812,
		-- Vampiric Blood
		55233,
		-- Starfall
		53201,
		53200,
		53199,
		48505,
		-- Bladestorm
		46924,
		-- Shadow Dance
		51713,
		-- Dancing Rune Weapon
		49028,
		-- Escape Artist
		20589,
		-- Shadowmeld
		58984,
		-- Gift of the Naaru
		28880,
		59542,
		59543,
		59544,
		59545,
		59547,
		59548,
		-- Will of the Forsaken
		7744,
		-- Every Man for Himself
		59752,
		-- PvP Trinket
		42292,
		-- Anti-Magic Zone
		50461,
		-- Aura Mastery
		31821,
		-- Icebound Fortitude
		48792,
		-- Lichborne
		49039,
		-- Dispersion
		47585,
		-- Divine Sacrifice
		64205,
		-- Hand of Sacrifice
		6940,
		-- Death Pact
		48743,
		-- Power Infusion
		10060,
		-- Bestial Wrath
		19574,
		-- Killing Spree
		51690,
		-- Arcane Power
		12042,
		-- Combustion
		28682,
		-- Presence of Mind
		12043,
		-- Nature's Swiftness
		16188,
		17116,
		-- Fel Domination
		18708,
		-- Invisibility
		66,
		-- Evasion
		26669,
		5277,
		-- Vanish
		26889,
		1857,
		1856,
		-- Adrenaline Rush
		13750,
		-- Avenging Wrath
		31884,
		-- Metamorphosis
		47241,
		-- Icy Veins
		12472,
		-- Berserk
		50334,
		-- Death Wish
		12292,
		-- Elemental Mastery
		16166,
		-- Feral Spirit
		51533,
		-- Force of Nature
		33831,
		-- Summon Gargoyle
		49206,
		-- Innervate
		29166,
		-- Divine Illumination
		31842,
		-- Frenzied Regeneration
		22842,
		-- Enraged Regeneration
		55694,
		-- Last Stand
		12975,
		-- Survival Instincts
		61336,
		-- Hysteria
		49016,
		-- Mark of Blood
		49005,
		-- Guardian Spirit
		47788,
		-- Pain Suppression
		33206,
		-- Divine Protection
		498,
		-- Readiness
		23989,
		-- Evocation
		12051,
		-- Rapid Fire
		3045,
		-- Bloodlust
		2825,
		-- Heroism
		32182,
		-- Recklessness
		1719,
		-- Retaliation
		20230,
		-- Shield Wall
		871,
		-- Hand of Protection
		10278,
		5599,
		1022,
		-- Divine Shield
		642,
		-- Ice Block
		45438,
		-- Empower Rune Weapon
		47568,
		-- Shadowfiend
		34433,
		-- Hymn of Hope
		64901,
		-- Cold Snap
		11958,
		-- Preparation
		14185,
		-- Tranquility
		48447,
		48446,
		26983,
		9863,
		9862,
		8918,
		740,
		-- Divine Hymn
		64843,
		-- Divine Intervention
		19752,
		-- Rebirth
		48477,
		26994,
		20748,
		20747,
		20742,
		20739,
		20484,
		-- Army of the Dead
		42650,
		-- Earth Elemental Totem
		2062,
		-- Fire Elemental Totem
		2894,
		-- Lay on Hands
		48788,
		27154,
		10310,
		2800,
		633,
	}
else
	AddOn.spellDB = {
		-- Consume Shadows
		54501,
		-- Aspect of the Cheetah
		5118,
		-- Tremor Totem
		8143,
		-- Immolation Trap
		13795,
		-- Bloodrage
		29131,
		-- Enrage
		5229,
		-- Stoneclaw Totem
		6390,
		-- Sacrifice
		7812,
		-- Shield Block
		2565,
		-- Healing Potion
		441,
		-- Swiftness Potion
		2379,
		-- Nature's Grasp
		16810,
		16689,
		-- Escape Artist
		20589,
		-- Shadowmeld
		58984,
		-- Will of the Forsaken
		7744,
		-- Every Man for Himself
		59752,
		-- Gift of the Naaru
		28880,
		59542,
		59543,
		59544,
		59547,
		59548,
		-- Lifeblood
		55500,
		55480,
		55428,
		-- Evasion
		5277,
		-- Sprint
		2983,
		-- Divine Protection
		498,
		-- Hand of Protection
		1022,
		-- Thistle Tea
		9512,
		-- PvP Trinket
		42292,
		-- Arena Grand Master
		23506,
		-- Lay on Hands
		633,
	}
end